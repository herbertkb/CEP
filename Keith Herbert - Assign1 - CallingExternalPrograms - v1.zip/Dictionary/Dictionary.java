/******************************************************************************
	Dictionary.java
	
	Simple program that takes an English word and a translation file as input
	and returns the word's translation as output. 
	
	Translation file must be formated as:
	*QueryWord* *tab* *TranslatedWord*
	
*******************************************************************************
	To run:
		java Dictionary *englishWord* *translationFile*
		
	Example:
		> java Dictionary boy English2Russian.txt
		мальчик
		>
		> java Dictionary fnord Englist2Russian.txt
		FNORD not found in translation file "English2Russian.txt". 

*******************************************************************************
	Maintenance Log
	Fix #	Date		Name	Description
	0001	20 May 2014	Keith	First draft. Many back and forth revisions to 
								fix issues with Cyrillic output to Windows
								console. 
	0002	21 May 2014	Keith	More fiddling to fix Cyrillic output to 
								Windows console. 
	0003	25 May 2014	Keith	Minor variable name changes for clarity.



******************************************************************************/

import java.util.Scanner;			// to parse the translation file
import java.io.File;				// to work with scanner to open trans file
import java.io.PrintStream; 		// to force printing in Unicode

public class Dictionary {
	public static void main(String[] args) 
		throws java.io.FileNotFoundException, 
			   java.io.UnsupportedEncodingException {
		
		//	Parse commandline arguments.///////////////////////////////////////
		//	args[0] must be the word to be translated
		//	args[1] must be the filename for the translation file//////////////
		String word = args[0];
		String wordlist = args[1];
		
		// Open the translation file.//////////////////////////////////////////
		Scanner parser = new Scanner(new File(wordlist), "UTF-8");
		
		// Search the translation file for the query word./////////////////////
		// Loop invariant: At each line of the translation file, none of the 
		// 	preceding lines contained the query word. 
		// Initialization: The word cannot be found before searching.
		// Termination: When the word is found, its translation is saved and
		//	the loop exits.////////////////////////////////////////////////////
		String transWord = word.toUpperCase() + " not found in dictionary.";
		while ( parser.hasNextLine() ) {
			
			// Each line is split in two parts. The first is the query word and
			//	the second is its translation. ////////////////////////////////
			String line = parser.nextLine();
			line = line.trim();
			String currentWord = line.split("\t")[0];
			
			// The query word is checked for a match. /////////////////////////
			// If successful, its translation is saved and the loop exits./////
			if ( word.equalsIgnoreCase(currentWord) ) {
				transWord = line.split("\t")[1];
				break;
			}
		}
		
		// Close the translation file handle now that we are finished with it./
		parser.close();
		
		// By default, System.out prints to the native character encoding.
		// We must use a PrintStream object to force it to print Unicode for
		//	non-Latin characters. /////////////////////////////////////////////
		PrintStream out = new PrintStream(System.out, true, "UTF-8");
		out.println(transWord);
		
	}
}